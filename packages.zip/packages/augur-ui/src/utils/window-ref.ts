import { WindowApp } from "modules/types";

export const windowRef: WindowApp = (window as WindowApp & typeof globalThis);
