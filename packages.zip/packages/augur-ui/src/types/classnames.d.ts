export = index;
declare function index(...args: any[]): any;
