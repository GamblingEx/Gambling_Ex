import * as abi from './abi.json';
import  * as abiV1 from './abi.json';
export { abi, abiV1 };

export { ContractEvents } from './events';
export * from './configuration';
