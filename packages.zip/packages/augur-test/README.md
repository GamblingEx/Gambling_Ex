# Augur Test

Integration tests for Augur.

The tests live under `tests/`.
The helpers for the tests live under `libs/`.
