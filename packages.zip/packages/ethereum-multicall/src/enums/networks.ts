export enum Networks {
  mainnet = 1,
  ropsten = 3,
  rinkeby = 4,
  kovan = 42,
}
