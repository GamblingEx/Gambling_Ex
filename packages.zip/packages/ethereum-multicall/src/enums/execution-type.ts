export enum ExecutionType {
  web3 = 'web3',
  ethers = 'ethers',
  customHttp = 'custom',
}
