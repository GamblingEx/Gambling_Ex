export {
  CallReturnContext,
  ContractCallContext,
  ContractCallResults,
  ContractCallReturnContext,
} from './models';
export * from './models/multicall-options';
export { Multicall } from './multicall';
