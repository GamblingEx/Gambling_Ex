# This file is not a real private key

This private key is used for development so that we can actually set up the
proper URL for the 0x bootstrap node. This private key determines the bootstrap
node CID, which is hardcoded into the UI as a bootstrap server.

Any bounties submitted related to this key will not be granted as valid.

Note: *Do not use this key anywhere else*
