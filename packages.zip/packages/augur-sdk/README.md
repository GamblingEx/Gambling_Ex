# Augur SDK

Augur SDK Sycning and Querying Utilities

To run in the browser
```sh
$ yarn webpack-dev-server
```

Then visit http://localhost:8080
