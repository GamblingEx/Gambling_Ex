# Contribute

Please contribute! Here are some things that would be great:

- [Open an issue!](https://github.com/orbitdb/orbit-web/issues/new)
- Open a pull request!
- Say hi! :wave:

Please note that we have a [Code of Conduct](CODE_OF_CONDUCT.md), and that all activity in the [@OrbitDB](https://github.com/orbitdb) organization falls under it. Read it when you get the chance, as being part of this community means that you agree to abide by it. Thanks.
