module.exports = {
  launch: {
    dumpio: false,
    headless: true
  },
  server: {
    command: 'npm run test-server',
    port: 8088
  }
}
