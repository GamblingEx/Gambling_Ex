# Ethers.JS Provider Implementation for Augur API

Ethers.JS Provider Implementation for Augur API
