# Augur SDK Lite

Augur SDK Intended for use within very limited contexts only capable of doing minimal loading

