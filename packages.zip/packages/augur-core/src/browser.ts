import * as GenericAugurInterfaces from "./libraries/GenericContractInterfaces";
import * as ContractInterfaces from "./libraries/ContractInterfaces";
export {
    GenericAugurInterfaces,
    ContractInterfaces
}
