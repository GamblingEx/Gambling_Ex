---
id: doc2
title: document number 2
---

This is a link to [another document.](doc3.md)  
This is a link to an [external page.](http://www.example.com)
