BID = 0
ASK = 1
LONG = 0
SHORT = 1
YES = 2
NO = 1
