#!/bin/bash

python ../upload_contracts/upload_contracts.py update -s ../source/contracts
