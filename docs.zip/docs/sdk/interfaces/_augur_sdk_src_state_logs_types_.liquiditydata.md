[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [LiquidityData](_augur_sdk_src_state_logs_types_.liquiditydata.md)

# Interface: LiquidityData

## Hierarchy

* **LiquidityData**

## Indexable

* \[ **spread**: *number*\]: number
