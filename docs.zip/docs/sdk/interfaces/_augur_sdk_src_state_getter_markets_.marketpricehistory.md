[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [MarketPriceHistory](_augur_sdk_src_state_getter_markets_.marketpricehistory.md)

# Interface: MarketPriceHistory

## Hierarchy

* **MarketPriceHistory**

## Indexable

* \[ **outcome**: *string*\]: [TimestampedPriceAmount](_augur_sdk_src_state_getter_markets_.timestampedpriceamount.md)[]
