[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/Liquidity"](../modules/_augur_sdk_src_api_liquidity_.md) › [OrderBook](_augur_sdk_src_api_liquidity_.orderbook.md)

# Interface: OrderBook

## Hierarchy

* **OrderBook**

## Indexable

* \[ **outcome**: *number*\]: [OutcomeOrderBook](_augur_sdk_src_api_liquidity_.outcomeorderbook.md)
