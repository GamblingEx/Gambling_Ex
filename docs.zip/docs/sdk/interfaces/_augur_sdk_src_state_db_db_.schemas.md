[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/DB"](../modules/_augur_sdk_src_state_db_db_.md) › [Schemas](_augur_sdk_src_state_db_db_.schemas.md)

# Interface: Schemas

## Hierarchy

* **Schemas**

## Indexable

* \[ **table**: *string*\]: string
