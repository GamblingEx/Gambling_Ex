[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [CategoryStats](_augur_sdk_src_state_getter_markets_.categorystats.md)

# Interface: CategoryStats

## Hierarchy

* **CategoryStats**

## Indexable

* \[ **category**: *string*\]: [CategoryStat](_augur_sdk_src_state_getter_markets_.categorystat.md)
