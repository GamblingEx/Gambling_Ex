[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Ping"](../modules/_augur_sdk_src_state_getter_ping_.md) › [Pong](_augur_sdk_src_state_getter_ping_.pong.md)

# Interface: Pong

## Hierarchy

* **Pong**

## Index

### Properties

* [response](_augur_sdk_src_state_getter_ping_.pong.md#response)

## Properties

###  response

• **response**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Ping.ts:6](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Ping.ts#L6)*
