[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/HotLoading"](../modules/_augur_sdk_src_api_hotloading_.md) › [GetDisputeWindowParams](_augur_sdk_src_api_hotloading_.getdisputewindowparams.md)

# Interface: GetDisputeWindowParams

## Hierarchy

* **GetDisputeWindowParams**

## Index

### Properties

* [augur](_augur_sdk_src_api_hotloading_.getdisputewindowparams.md#augur)
* [universe](_augur_sdk_src_api_hotloading_.getdisputewindowparams.md#universe)

## Properties

###  augur

• **augur**: *[Address](../modules/_augur_sdk_src_state_logs_types_.md#address)*

*Defined in [packages/augur-sdk/src/api/HotLoading.ts:16](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/HotLoading.ts#L16)*

___

###  universe

• **universe**: *[Address](../modules/_augur_sdk_src_state_logs_types_.md#address)*

*Defined in [packages/augur-sdk/src/api/HotLoading.ts:17](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/HotLoading.ts#L17)*
