[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/ZeroXOrders"](../modules/_augur_sdk_src_state_db_zeroxorders_.md) › [ParsedAssetDataResults](_augur_sdk_src_state_db_zeroxorders_.parsedassetdataresults.md)

# Interface: ParsedAssetDataResults

## Hierarchy

* **ParsedAssetDataResults**

## Index

### Properties

* [multiAssetData](_augur_sdk_src_state_db_zeroxorders_.parsedassetdataresults.md#multiassetdata)
* [orderData](_augur_sdk_src_state_db_zeroxorders_.parsedassetdataresults.md#orderdata)

## Properties

###  multiAssetData

• **multiAssetData**: *any*

*Defined in [packages/augur-sdk/src/state/db/ZeroXOrders.ts:55](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/ZeroXOrders.ts#L55)*

___

###  orderData

• **orderData**: *[OrderData](_augur_sdk_src_state_db_zeroxorders_.orderdata.md)*

*Defined in [packages/augur-sdk/src/state/db/ZeroXOrders.ts:54](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/ZeroXOrders.ts#L54)*
