[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/ZeroXOrders"](../modules/_augur_sdk_src_state_db_zeroxorders_.md) › [SnapshotCounterDocument](_augur_sdk_src_state_db_zeroxorders_.snapshotcounterdocument.md)

# Interface: SnapshotCounterDocument

## Hierarchy

* [BaseDocument](_augur_sdk_src_state_db_abstracttable_.basedocument.md)

  ↳ **SnapshotCounterDocument**

## Indexable

* \[ **key**: *string*\]: any

## Index

### Properties

* [snapshotCounter](_augur_sdk_src_state_db_zeroxorders_.snapshotcounterdocument.md#snapshotcounter)

## Properties

###  snapshotCounter

• **snapshotCounter**: *number*

*Defined in [packages/augur-sdk/src/state/db/ZeroXOrders.ts:71](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/ZeroXOrders.ts#L71)*
