[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/ZeroXOrdersGetters"](../modules/_augur_sdk_src_state_getter_zeroxordersgetters_.md) › [ZeroXOrders](_augur_sdk_src_state_getter_zeroxordersgetters_.zeroxorders.md)

# Interface: ZeroXOrders

## Hierarchy

* **ZeroXOrders**

## Indexable

* \[ **marketId**: *string*\]: object

* \[ **outcome**: *number*\]: object

* \[ **orderType**: *string*\]: object

* \[ **orderId**: *string*\]: [ZeroXOrder](_augur_sdk_src_state_getter_zeroxordersgetters_.zeroxorder.md)
