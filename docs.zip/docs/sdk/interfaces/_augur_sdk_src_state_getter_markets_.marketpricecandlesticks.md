[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [MarketPriceCandlesticks](_augur_sdk_src_state_getter_markets_.marketpricecandlesticks.md)

# Interface: MarketPriceCandlesticks

## Hierarchy

* **MarketPriceCandlesticks**

## Indexable

* \[ **outcome**: *number*\]: [MarketPriceCandlestick](_augur_sdk_src_state_getter_markets_.marketpricecandlestick.md)[]
