[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/OnChainTrading"](../modules/_augur_sdk_src_state_getter_onchaintrading_.md) › [AllOrders](_augur_sdk_src_state_getter_onchaintrading_.allorders.md)

# Interface: AllOrders

## Hierarchy

* **AllOrders**

## Indexable

* \[ **orderId**: *string*\]: object

* **marketId**: *[Address](../modules/_augur_sdk_src_state_logs_types_.md#address)*

* **orderId**: *[Address](../modules/_augur_sdk_src_state_logs_types_.md#address)*

* **sharesEscrowed**: *string*

* **tokensEscrowed**: *string*
