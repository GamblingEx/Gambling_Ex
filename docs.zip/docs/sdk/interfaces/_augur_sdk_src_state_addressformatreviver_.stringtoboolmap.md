[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/AddressFormatReviver"](../modules/_augur_sdk_src_state_addressformatreviver_.md) › [StringToBoolMap](_augur_sdk_src_state_addressformatreviver_.stringtoboolmap.md)

# Interface: StringToBoolMap

## Hierarchy

* **StringToBoolMap**

## Indexable

* \[ **key**: *string*\]: boolean
