[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/subscriptions"](../modules/_augur_sdk_src_subscriptions_.md) › [WaitingOn](_augur_sdk_src_subscriptions_.waitingon.md)

# Interface: WaitingOn

## Hierarchy

* **WaitingOn**

## Indexable

* \[ **eventName**: *string*\]: [EventData](_augur_sdk_src_subscriptions_.eventdata.md)[]
