[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Accounts"](../modules/_augur_sdk_src_state_getter_accounts_.md) › [MarketCreatedInfo](_augur_sdk_src_state_getter_accounts_.marketcreatedinfo.md)

# Interface: MarketCreatedInfo

## Hierarchy

* **MarketCreatedInfo**

## Indexable

* \[ **key**: *string*\]: [MarketData](_augur_sdk_src_state_logs_types_.marketdata.md)
