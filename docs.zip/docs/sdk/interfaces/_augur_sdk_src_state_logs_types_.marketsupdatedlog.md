[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [MarketsUpdatedLog](_augur_sdk_src_state_logs_types_.marketsupdatedlog.md)

# Interface: MarketsUpdatedLog

## Hierarchy

* **MarketsUpdatedLog**

## Index

### Properties

* [data](_augur_sdk_src_state_logs_types_.marketsupdatedlog.md#data)

## Properties

###  data

• **data**: *[MarketData](_augur_sdk_src_state_logs_types_.marketdata.md)[]*

*Defined in [packages/augur-sdk/src/state/logs/types.ts:30](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L30)*
