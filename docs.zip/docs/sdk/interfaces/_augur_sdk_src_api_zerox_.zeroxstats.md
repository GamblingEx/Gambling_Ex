[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/ZeroX"](../modules/_augur_sdk_src_api_zerox_.md) › [ZeroXStats](_augur_sdk_src_api_zerox_.zeroxstats.md)

# Interface: ZeroXStats

## Hierarchy

* **ZeroXStats**

## Index

### Properties

* [orders](_augur_sdk_src_api_zerox_.zeroxstats.md#orders)
* [peers](_augur_sdk_src_api_zerox_.zeroxstats.md#peers)

## Properties

###  orders

• **orders**: *number*

*Defined in [packages/augur-sdk/src/api/ZeroX.ts:78](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/ZeroX.ts#L78)*

___

###  peers

• **peers**: *number*

*Defined in [packages/augur-sdk/src/api/ZeroX.ts:77](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/ZeroX.ts#L77)*
