[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Users"](../modules/_augur_sdk_src_state_getter_users_.md) › [UserTotalOnChainFrozenFunds](_augur_sdk_src_state_getter_users_.usertotalonchainfrozenfunds.md)

# Interface: UserTotalOnChainFrozenFunds

## Hierarchy

* **UserTotalOnChainFrozenFunds**

## Index

### Properties

* [totalFrozenFunds](_augur_sdk_src_state_getter_users_.usertotalonchainfrozenfunds.md#totalfrozenfunds)

## Properties

###  totalFrozenFunds

• **totalFrozenFunds**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Users.ts:174](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Users.ts#L174)*
