[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Users"](../modules/_augur_sdk_src_state_getter_users_.md) › [UserOpenOrders](_augur_sdk_src_state_getter_users_.useropenorders.md)

# Interface: UserOpenOrders

## Hierarchy

* **UserOpenOrders**

## Index

### Properties

* [orders](_augur_sdk_src_state_getter_users_.useropenorders.md#orders)
* [totalOpenOrdersFrozenFunds](_augur_sdk_src_state_getter_users_.useropenorders.md#totalopenordersfrozenfunds)

## Properties

###  orders

• **orders**: *[ZeroXOrders](_augur_sdk_src_state_getter_zeroxordersgetters_.zeroxorders.md)*

*Defined in [packages/augur-sdk/src/state/getter/Users.ts:79](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Users.ts#L79)*

___

###  totalOpenOrdersFrozenFunds

• **totalOpenOrdersFrozenFunds**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Users.ts:80](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Users.ts#L80)*
