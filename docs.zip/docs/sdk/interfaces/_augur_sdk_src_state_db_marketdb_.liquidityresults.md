[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/MarketDB"](../modules/_augur_sdk_src_state_db_marketdb_.md) › [LiquidityResults](_augur_sdk_src_state_db_marketdb_.liquidityresults.md)

# Interface: LiquidityResults

## Hierarchy

* **LiquidityResults**

## Indexable

* \[ **liquidity**: *number*\]: number
