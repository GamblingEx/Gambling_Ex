[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [TimestampedPriceAmount](_augur_sdk_src_state_getter_markets_.timestampedpriceamount.md)

# Interface: TimestampedPriceAmount

## Hierarchy

* **TimestampedPriceAmount**

## Index

### Properties

* [amount](_augur_sdk_src_state_getter_markets_.timestampedpriceamount.md#amount)
* [price](_augur_sdk_src_state_getter_markets_.timestampedpriceamount.md#price)
* [timestamp](_augur_sdk_src_state_getter_markets_.timestampedpriceamount.md#timestamp)

## Properties

###  amount

• **amount**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:218](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L218)*

___

###  price

• **price**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:217](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L217)*

___

###  timestamp

• **timestamp**: *string*

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:219](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L219)*
