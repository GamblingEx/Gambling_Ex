[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/OnChainTrading"](../modules/_augur_sdk_src_state_getter_onchaintrading_.md) › [MarketTradingHistory](_augur_sdk_src_state_getter_onchaintrading_.markettradinghistory.md)

# Interface: MarketTradingHistory

## Hierarchy

* **MarketTradingHistory**

## Indexable

* \[ **marketId**: *string*\]: [MarketTrade](_augur_sdk_src_state_getter_onchaintrading_.markettrade.md)[]
