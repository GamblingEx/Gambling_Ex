[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-types/types/logs"](../modules/_augur_types_types_logs_.md) › [LogValues](_augur_types_types_logs_.logvalues.md)

# Interface: LogValues

## Hierarchy

* **LogValues**

## Indexable

* \[ **paramName**: *string*\]: any
