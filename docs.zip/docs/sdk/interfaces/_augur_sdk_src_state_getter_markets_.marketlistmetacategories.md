[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [MarketListMetaCategories](_augur_sdk_src_state_getter_markets_.marketlistmetacategories.md)

# Interface: MarketListMetaCategories

## Hierarchy

* **MarketListMetaCategories**

## Indexable

* \[ **key**: *string*\]: object

* **children**(): *object*

* **count**: *number*
