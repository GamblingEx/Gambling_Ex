[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/HotLoading"](../modules/_augur_sdk_src_api_hotloading_.md) › [GetMarketDataParams](_augur_sdk_src_api_hotloading_.getmarketdataparams.md)

# Interface: GetMarketDataParams

## Hierarchy

* **GetMarketDataParams**

## Index

### Properties

* [market](_augur_sdk_src_api_hotloading_.getmarketdataparams.md#market)

## Properties

###  market

• **market**: *string*

*Defined in [packages/augur-sdk/src/api/HotLoading.ts:29](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/HotLoading.ts#L29)*
