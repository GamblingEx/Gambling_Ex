[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/Liquidity"](../modules/_augur_sdk_src_api_liquidity_.md) › [Order](_augur_sdk_src_api_liquidity_.order.md)

# Interface: Order

## Hierarchy

* **Order**

## Index

### Properties

* [amount](_augur_sdk_src_api_liquidity_.order.md#amount)
* [price](_augur_sdk_src_api_liquidity_.order.md#price)

## Properties

###  amount

• **amount**: *string*

*Defined in [packages/augur-sdk/src/api/Liquidity.ts:10](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/Liquidity.ts#L10)*

___

###  price

• **price**: *string*

*Defined in [packages/augur-sdk/src/api/Liquidity.ts:9](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/Liquidity.ts#L9)*
