[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Platform"](../modules/_augur_sdk_src_state_getter_platform_.md) › [TimeConstraint](_augur_sdk_src_state_getter_platform_.timeconstraint.md)

# Interface: TimeConstraint

## Hierarchy

* **TimeConstraint**

## Index

### Properties

* [$and](_augur_sdk_src_state_getter_platform_.timeconstraint.md#and)

## Properties

###  $and

• **$and**: *Array‹object›*

*Defined in [packages/augur-sdk/src/state/getter/Platform.ts:183](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Platform.ts#L183)*
