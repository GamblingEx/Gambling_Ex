[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/OnChainTrading"](../modules/_augur_sdk_src_state_getter_onchaintrading_.md) › [Orders](_augur_sdk_src_state_getter_onchaintrading_.orders.md)

# Interface: Orders

## Hierarchy

* **Orders**

## Indexable

* \[ **marketId**: *string*\]: object

* \[ **outcome**: *number*\]: object

* \[ **orderType**: *string*\]: object

* \[ **orderId**: *string*\]: [Order](_augur_sdk_src_state_getter_onchaintrading_.order.md)
