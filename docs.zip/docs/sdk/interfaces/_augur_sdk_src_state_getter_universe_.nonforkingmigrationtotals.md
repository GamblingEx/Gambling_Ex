[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Universe"](../modules/_augur_sdk_src_state_getter_universe_.md) › [NonForkingMigrationTotals](_augur_sdk_src_state_getter_universe_.nonforkingmigrationtotals.md)

# Interface: NonForkingMigrationTotals

## Hierarchy

* **NonForkingMigrationTotals**
