[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/WarpSyncCheckpointsDB"](../modules/_augur_sdk_src_state_db_warpsynccheckpointsdb_.md) › [IpfsInfo](_augur_sdk_src_state_db_warpsynccheckpointsdb_.ipfsinfo.md)

# Interface: IpfsInfo

## Hierarchy

* **IpfsInfo**

## Index

### Properties

* [Hash](_augur_sdk_src_state_db_warpsynccheckpointsdb_.ipfsinfo.md#hash)
* [Name](_augur_sdk_src_state_db_warpsynccheckpointsdb_.ipfsinfo.md#name)
* [Size](_augur_sdk_src_state_db_warpsynccheckpointsdb_.ipfsinfo.md#size)

## Properties

###  Hash

• **Hash**: *string*

*Defined in [packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts:9](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts#L9)*

___

###  Name

• **Name**: *string*

*Defined in [packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts:8](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts#L8)*

___

###  Size

• **Size**: *0*

*Defined in [packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts:10](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/WarpSyncCheckpointsDB.ts#L10)*
