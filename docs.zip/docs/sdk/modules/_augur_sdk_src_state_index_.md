[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/index"](_augur_sdk_src_state_index_.md)

# Module: "augur-sdk/src/state/index"

## Index

### References

* [UnixTimestamp](_augur_sdk_src_state_index_.md#unixtimestamp)
* [buildSyncStrategies](_augur_sdk_src_state_index_.md#buildsyncstrategies)
* [createClient](_augur_sdk_src_state_index_.md#createclient)
* [createServer](_augur_sdk_src_state_index_.md#createserver)
* [startServer](_augur_sdk_src_state_index_.md#startserver)
* [startServerFromClient](_augur_sdk_src_state_index_.md#startserverfromclient)

## References

###  UnixTimestamp

• **UnixTimestamp**:

___

###  buildSyncStrategies

• **buildSyncStrategies**:

___

###  createClient

• **createClient**:

___

###  createServer

• **createServer**:

___

###  startServer

• **startServer**:

___

###  startServerFromClient

• **startServerFromClient**:
