[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/DerivedDB"](_augur_sdk_src_state_db_deriveddb_.md)

# Module: "augur-sdk/src/state/db/DerivedDB"

## Index

### Classes

* [DerivedDB](../classes/_augur_sdk_src_state_db_deriveddb_.deriveddb.md)

### Interfaces

* [Document](../interfaces/_augur_sdk_src_state_db_deriveddb_.document.md)
