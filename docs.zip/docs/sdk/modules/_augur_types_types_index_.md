[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-types/types/index"](_augur_types_types_index_.md)

# Module: "augur-types/types/index"

## Index

### References

* [ContractEvents](_augur_types_types_index_.md#contractevents)
* [Filter](_augur_types_types_index_.md#filter)
* [Log](_augur_types_types_index_.md#log)
* [LogValues](_augur_types_types_index_.md#logvalues)
* [ParsedLog](_augur_types_types_index_.md#parsedlog)

## References

###  ContractEvents

• **ContractEvents**:

___

###  Filter

• **Filter**:

___

###  Log

• **Log**:

___

###  LogValues

• **LogValues**:

___

###  ParsedLog

• **ParsedLog**:
