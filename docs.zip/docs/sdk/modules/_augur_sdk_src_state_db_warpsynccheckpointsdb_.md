[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/WarpSyncCheckpointsDB"](_augur_sdk_src_state_db_warpsynccheckpointsdb_.md)

# Module: "augur-sdk/src/state/db/WarpSyncCheckpointsDB"

## Index

### Classes

* [WarpSyncCheckpointsDB](../classes/_augur_sdk_src_state_db_warpsynccheckpointsdb_.warpsynccheckpointsdb.md)

### Interfaces

* [IpfsInfo](../interfaces/_augur_sdk_src_state_db_warpsynccheckpointsdb_.ipfsinfo.md)
* [WarpCheckpointDocument](../interfaces/_augur_sdk_src_state_db_warpsynccheckpointsdb_.warpcheckpointdocument.md)
