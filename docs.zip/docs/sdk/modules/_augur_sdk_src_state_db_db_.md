[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/DB"](_augur_sdk_src_state_db_db_.md)

# Module: "augur-sdk/src/state/db/DB"

## Index

### Classes

* [DB](../classes/_augur_sdk_src_state_db_db_.db.md)

### Interfaces

* [Schemas](../interfaces/_augur_sdk_src_state_db_db_.schemas.md)

### Variables

* [PRUNE_HORIZON](_augur_sdk_src_state_db_db_.md#const-prune_horizon)

## Variables

### `Const` PRUNE_HORIZON

• **PRUNE_HORIZON**: *number* = SECONDS_IN_A_DAY.multipliedBy(60).toNumber()

*Defined in [packages/augur-sdk/src/state/db/DB.ts:64](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/DB.ts#L64)*
