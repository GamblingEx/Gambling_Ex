[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/sync/BulkSyncStrategy.test"](_augur_sdk_src_state_sync_bulksyncstrategy_test_.md)

# Module: "augur-sdk/src/state/sync/BulkSyncStrategy.test"


