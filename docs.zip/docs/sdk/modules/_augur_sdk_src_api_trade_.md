[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/Trade"](_augur_sdk_src_api_trade_.md)

# Module: "augur-sdk/src/api/Trade"

## Index

### Classes

* [Trade](../classes/_augur_sdk_src_api_trade_.trade.md)

### Interfaces

* [PlaceTradeDisplayParams](../interfaces/_augur_sdk_src_api_trade_.placetradedisplayparams.md)
* [PlaceTradeParams](../interfaces/_augur_sdk_src_api_trade_.placetradeparams.md)
* [SimulateTradeData](../interfaces/_augur_sdk_src_api_trade_.simulatetradedata.md)
* [TradeAPI](../interfaces/_augur_sdk_src_api_trade_.tradeapi.md)
