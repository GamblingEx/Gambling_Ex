[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/WarpSyncGetter"](_augur_sdk_src_state_getter_warpsyncgetter_.md)

# Module: "augur-sdk/src/state/getter/WarpSyncGetter"

## Index

### Classes

* [WarpSyncGetter](../classes/_augur_sdk_src_state_getter_warpsyncgetter_.warpsyncgetter.md)
