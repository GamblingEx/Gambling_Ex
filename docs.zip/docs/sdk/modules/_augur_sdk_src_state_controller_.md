[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/Controller"](_augur_sdk_src_state_controller_.md)

# Module: "augur-sdk/src/state/Controller"

## Index

### Classes

* [Controller](../classes/_augur_sdk_src_state_controller_.controller.md)

### Variables

* [settings](_augur_sdk_src_state_controller_.md#const-settings)

## Variables

### `Const` settings

• **settings**: *any* = require('./settings.json')

*Defined in [packages/augur-sdk/src/state/Controller.ts:12](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/Controller.ts#L12)*
