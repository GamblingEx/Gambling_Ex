[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/sync/BulkSyncStrategy"](_augur_sdk_src_state_sync_bulksyncstrategy_.md)

# Module: "augur-sdk/src/state/sync/BulkSyncStrategy"

## Index

### Classes

* [BulkSyncStrategy](../classes/_augur_sdk_src_state_sync_bulksyncstrategy_.bulksyncstrategy.md)
