[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/LogFilterAggregator.test"](_augur_sdk_src_state_logs_logfilteraggregator_test_.md)

# Module: "augur-sdk/src/state/logs/LogFilterAggregator.test"

## Index

### Type aliases

* [Mockify](_augur_sdk_src_state_logs_logfilteraggregator_test_.md#mockify)

## Type aliases

###  Mockify

Ƭ **Mockify**: *object*

*Defined in [packages/augur-sdk/src/state/logs/LogFilterAggregator.test.ts:11](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/LogFilterAggregator.test.ts#L11)*

#### Type declaration:
