[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/ContractEvents.test"](_augur_sdk_src_api_contractevents_test_.md)

# Module: "augur-sdk/src/api/ContractEvents.test"

## Index

### Functions

* [makeProviderMock](_augur_sdk_src_api_contractevents_test_.md#makeprovidermock)

## Functions

###  makeProviderMock

▸ **makeProviderMock**(`opts?`: any): *[Provider](../interfaces/_augur_sdk_src_ethereum_provider_.provider.md)*

*Defined in [packages/augur-sdk/src/api/ContractEvents.test.ts:8](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/ContractEvents.test.ts#L8)*

**Parameters:**

Name | Type |
------ | ------ |
`opts?` | any |

**Returns:** *[Provider](../interfaces/_augur_sdk_src_ethereum_provider_.provider.md)*
