[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Ping"](_augur_sdk_src_state_getter_ping_.md)

# Module: "augur-sdk/src/state/getter/Ping"

## Index

### Classes

* [Ping](../classes/_augur_sdk_src_state_getter_ping_.ping.md)

### Interfaces

* [Pong](../interfaces/_augur_sdk_src_state_getter_ping_.pong.md)
