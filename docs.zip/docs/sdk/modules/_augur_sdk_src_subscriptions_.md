[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/subscriptions"](_augur_sdk_src_subscriptions_.md)

# Module: "augur-sdk/src/subscriptions"

## Index

### Classes

* [Subscriptions](../classes/_augur_sdk_src_subscriptions_.subscriptions.md)

### Interfaces

* [EventData](../interfaces/_augur_sdk_src_subscriptions_.eventdata.md)
* [WaitingOn](../interfaces/_augur_sdk_src_subscriptions_.waitingon.md)
