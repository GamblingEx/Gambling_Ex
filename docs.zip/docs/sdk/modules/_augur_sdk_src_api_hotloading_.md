[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/HotLoading"](_augur_sdk_src_api_hotloading_.md)

# Module: "augur-sdk/src/api/HotLoading"

## Index

### Classes

* [HotLoading](../classes/_augur_sdk_src_api_hotloading_.hotloading.md)

### Interfaces

* [DisputeWindow](../interfaces/_augur_sdk_src_api_hotloading_.disputewindow.md)
* [GetDisputeWindowParams](../interfaces/_augur_sdk_src_api_hotloading_.getdisputewindowparams.md)
* [GetMarketDataParams](../interfaces/_augur_sdk_src_api_hotloading_.getmarketdataparams.md)
* [HotLoadMarketInfo](../interfaces/_augur_sdk_src_api_hotloading_.hotloadmarketinfo.md)
