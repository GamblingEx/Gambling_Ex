[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/DelayedSyncableDB"](_augur_sdk_src_state_db_delayedsyncabledb_.md)

# Module: "augur-sdk/src/state/db/DelayedSyncableDB"

## Index

### Classes

* [DelayedSyncableDB](../classes/_augur_sdk_src_state_db_delayedsyncabledb_.delayedsyncabledb.md)

### Interfaces

* [Document](../interfaces/_augur_sdk_src_state_db_delayedsyncabledb_.document.md)
