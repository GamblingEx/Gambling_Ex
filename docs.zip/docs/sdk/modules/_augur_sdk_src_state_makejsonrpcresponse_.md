[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/MakeJsonRpcResponse"](_augur_sdk_src_state_makejsonrpcresponse_.md)

# Module: "augur-sdk/src/state/MakeJsonRpcResponse"

## Index

### Functions

* [MakeJsonRpcResponse](_augur_sdk_src_state_makejsonrpcresponse_.md#makejsonrpcresponse)

## Functions

###  MakeJsonRpcResponse

▸ **MakeJsonRpcResponse**(`id`: string | null, `result`: object | boolean): *string*

*Defined in [packages/augur-sdk/src/state/MakeJsonRpcResponse.ts:1](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/MakeJsonRpcResponse.ts#L1)*

**Parameters:**

Name | Type |
------ | ------ |
`id` | string &#124; null |
`result` | object &#124; boolean |

**Returns:** *string*
