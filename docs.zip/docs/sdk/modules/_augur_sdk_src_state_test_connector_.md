[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/test-connector"](_augur_sdk_src_state_test_connector_.md)

# Module: "augur-sdk/src/state/test-connector"

## Index

### Variables

* [settings](_augur_sdk_src_state_test_connector_.md#const-settings)

## Variables

### `Const` settings

• **settings**: *any* = require('@augurproject/sdk/src/state/settings.json')

*Defined in [packages/augur-sdk/src/state/test-connector.ts:11](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/test-connector.ts#L11)*
