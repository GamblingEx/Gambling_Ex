[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/index"](_augur_sdk_src_state_getter_index_.md)

# Module: "augur-sdk/src/state/getter/index"


