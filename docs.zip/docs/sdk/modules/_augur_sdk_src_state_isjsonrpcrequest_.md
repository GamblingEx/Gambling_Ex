[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/IsJsonRpcRequest"](_augur_sdk_src_state_isjsonrpcrequest_.md)

# Module: "augur-sdk/src/state/IsJsonRpcRequest"

## Index

### Functions

* [IsJsonRpcRequest](_augur_sdk_src_state_isjsonrpcrequest_.md#isjsonrpcrequest)

## Functions

###  IsJsonRpcRequest

▸ **IsJsonRpcRequest**(`message`: any): *boolean*

*Defined in [packages/augur-sdk/src/state/IsJsonRpcRequest.ts:1](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/IsJsonRpcRequest.ts#L1)*

**Parameters:**

Name | Type |
------ | ------ |
`message` | any |

**Returns:** *boolean*
