[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/CurrentOrdersDB"](_augur_sdk_src_state_db_currentordersdb_.md)

# Module: "augur-sdk/src/state/db/CurrentOrdersDB"

## Index

### Classes

* [CurrentOrdersDatabase](../classes/_augur_sdk_src_state_db_currentordersdb_.currentordersdatabase.md)
