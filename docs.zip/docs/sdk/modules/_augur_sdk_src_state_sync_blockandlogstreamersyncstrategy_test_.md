[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/sync/BlockAndLogStreamerSyncStrategy.test"](_augur_sdk_src_state_sync_blockandlogstreamersyncstrategy_test_.md)

# Module: "augur-sdk/src/state/sync/BlockAndLogStreamerSyncStrategy.test"

## Index

### Type aliases

* [Mockify](_augur_sdk_src_state_sync_blockandlogstreamersyncstrategy_test_.md#mockify)

## Type aliases

###  Mockify

Ƭ **Mockify**: *object*

*Defined in [packages/augur-sdk/src/state/sync/BlockAndLogStreamerSyncStrategy.test.ts:11](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/sync/BlockAndLogStreamerSyncStrategy.test.ts#L11)*

#### Type declaration:
