[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/ContractEvents"](_augur_sdk_src_api_contractevents_.md)

# Module: "augur-sdk/src/api/ContractEvents"

## Index

### Classes

* [ContractEvents](../classes/_augur_sdk_src_api_contractevents_.contractevents.md)
