[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/ethereum/Provider"](_augur_sdk_src_ethereum_provider_.md)

# Module: "augur-sdk/src/ethereum/Provider"

## Index

### Interfaces

* [Provider](../interfaces/_augur_sdk_src_ethereum_provider_.provider.md)
