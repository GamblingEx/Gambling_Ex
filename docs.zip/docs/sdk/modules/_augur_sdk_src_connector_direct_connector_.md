[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/direct-connector"](_augur_sdk_src_connector_direct_connector_.md)

# Module: "augur-sdk/src/connector/direct-connector"

## Index

### Classes

* [DirectConnector](../classes/_augur_sdk_src_connector_direct_connector_.directconnector.md)
