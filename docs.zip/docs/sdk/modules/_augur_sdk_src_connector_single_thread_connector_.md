[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/single-thread-connector"](_augur_sdk_src_connector_single_thread_connector_.md)

# Module: "augur-sdk/src/connector/single-thread-connector"

## Index

### Classes

* [SingleThreadConnector](../classes/_augur_sdk_src_connector_single_thread_connector_.singlethreadconnector.md)
