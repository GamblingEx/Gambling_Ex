[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/ws-connector"](_augur_sdk_src_connector_ws_connector_.md)

# Module: "augur-sdk/src/connector/ws-connector"

## Index

### Classes

* [WebsocketConnector](../classes/_augur_sdk_src_connector_ws_connector_.websocketconnector.md)
