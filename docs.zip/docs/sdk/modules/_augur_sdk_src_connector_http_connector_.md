[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/http-connector"](_augur_sdk_src_connector_http_connector_.md)

# Module: "augur-sdk/src/connector/http-connector"

## Index

### Classes

* [HTTPConnector](../classes/_augur_sdk_src_connector_http_connector_.httpconnector.md)
