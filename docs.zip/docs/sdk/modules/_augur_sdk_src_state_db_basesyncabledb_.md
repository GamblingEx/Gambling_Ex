[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/BaseSyncableDB"](_augur_sdk_src_state_db_basesyncabledb_.md)

# Module: "augur-sdk/src/state/db/BaseSyncableDB"

## Index

### Classes

* [BaseSyncableDB](../classes/_augur_sdk_src_state_db_basesyncabledb_.basesyncabledb.md)

### Interfaces

* [Document](../interfaces/_augur_sdk_src_state_db_basesyncabledb_.document.md)
