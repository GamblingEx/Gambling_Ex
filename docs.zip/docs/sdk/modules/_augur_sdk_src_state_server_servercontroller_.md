[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/server/ServerController"](_augur_sdk_src_state_server_servercontroller_.md)

# Module: "augur-sdk/src/state/server/ServerController"

## Index

### Classes

* [ServerController](../classes/_augur_sdk_src_state_server_servercontroller_.servercontroller.md)
