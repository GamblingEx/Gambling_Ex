[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/base-connector"](_augur_sdk_src_connector_base_connector_.md)

# Module: "augur-sdk/src/connector/base-connector"

## Index

### Classes

* [BaseConnector](../classes/_augur_sdk_src_connector_base_connector_.baseconnector.md)
