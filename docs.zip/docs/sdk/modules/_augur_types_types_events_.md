[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-types/types/events"](_augur_types_types_events_.md)

# Module: "augur-types/types/events"

## Index

### Enumerations

* [ContractEvents](../enums/_augur_types_types_events_.contractevents.md)
