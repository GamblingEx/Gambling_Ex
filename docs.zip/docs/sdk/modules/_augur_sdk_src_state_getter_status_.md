[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/status"](_augur_sdk_src_state_getter_status_.md)

# Module: "augur-sdk/src/state/getter/status"

## Index

### Classes

* [Status](../classes/_augur_sdk_src_state_getter_status_.status.md)

### Interfaces

* [SyncData](../interfaces/_augur_sdk_src_state_getter_status_.syncdata.md)
