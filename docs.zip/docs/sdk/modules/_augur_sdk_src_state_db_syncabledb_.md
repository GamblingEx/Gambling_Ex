[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/SyncableDB"](_augur_sdk_src_state_db_syncabledb_.md)

# Module: "augur-sdk/src/state/db/SyncableDB"

## Index

### Classes

* [SyncableDB](../classes/_augur_sdk_src_state_db_syncabledb_.syncabledb.md)

### Interfaces

* [Document](../interfaces/_augur_sdk_src_state_db_syncabledb_.document.md)
