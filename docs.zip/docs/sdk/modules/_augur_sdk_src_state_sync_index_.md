[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/sync/index"](_augur_sdk_src_state_sync_index_.md)

# Module: "augur-sdk/src/state/sync/index"

## Index

### Interfaces

* [SyncStrategy](../interfaces/_augur_sdk_src_state_sync_index_.syncstrategy.md)
