[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/DisputeDB"](_augur_sdk_src_state_db_disputedb_.md)

# Module: "augur-sdk/src/state/db/DisputeDB"

## Index

### Classes

* [DisputeDatabase](../classes/_augur_sdk_src_state_db_disputedb_.disputedatabase.md)
