[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/Market"](_augur_sdk_src_api_market_.md)

# Module: "augur-sdk/src/api/Market"

## Index

### Classes

* [Market](../classes/_augur_sdk_src_api_market_.market.md)

### Interfaces

* [CreateCategoricalMarketParams](../interfaces/_augur_sdk_src_api_market_.createcategoricalmarketparams.md)
* [CreateScalarMarketParams](../interfaces/_augur_sdk_src_api_market_.createscalarmarketparams.md)
* [CreateYesNoMarketParams](../interfaces/_augur_sdk_src_api_market_.createyesnomarketparams.md)
