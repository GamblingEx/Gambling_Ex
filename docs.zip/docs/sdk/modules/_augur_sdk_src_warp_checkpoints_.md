[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/warp/Checkpoints"](_augur_sdk_src_warp_checkpoints_.md)

# Module: "augur-sdk/src/warp/Checkpoints"

## Index

### Classes

* [Checkpoints](../classes/_augur_sdk_src_warp_checkpoints_.checkpoints.md)

### Type aliases

* [MarketWithEndTime](_augur_sdk_src_warp_checkpoints_.md#marketwithendtime)

## Type aliases

###  MarketWithEndTime

Ƭ **MarketWithEndTime**: *Pick‹[MarketCreated](../interfaces/_augur_sdk_src_event_handlers_.marketcreated.md), "blockNumber" | "endTime"›*

*Defined in [packages/augur-sdk/src/warp/Checkpoints.ts:16](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/warp/Checkpoints.ts#L16)*
