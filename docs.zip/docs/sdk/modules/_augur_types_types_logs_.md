[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-types/types/logs"](_augur_types_types_logs_.md)

# Module: "augur-types/types/logs"

## Index

### Interfaces

* [Filter](../interfaces/_augur_types_types_logs_.filter.md)
* [Log](../interfaces/_augur_types_types_logs_.log.md)
* [LogValues](../interfaces/_augur_types_types_logs_.logvalues.md)
* [ParsedLog](../interfaces/_augur_types_types_logs_.parsedlog.md)
