[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/SyncStatus"](_augur_sdk_src_state_db_syncstatus_.md)

# Module: "augur-sdk/src/state/db/SyncStatus"

## Index

### Classes

* [SyncStatus](../classes/_augur_sdk_src_state_db_syncstatus_.syncstatus.md)

### Interfaces

* [SyncDocument](../interfaces/_augur_sdk_src_state_db_syncstatus_.syncdocument.md)
