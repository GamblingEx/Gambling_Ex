[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/Augur"](_augur_sdk_src_augur_.md)

# Module: "augur-sdk/src/Augur"

## Index

### Classes

* [Augur](../classes/_augur_sdk_src_augur_.augur.md)
