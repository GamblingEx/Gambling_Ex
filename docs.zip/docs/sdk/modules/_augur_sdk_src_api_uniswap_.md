[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/api/Uniswap"](_augur_sdk_src_api_uniswap_.md)

# Module: "augur-sdk/src/api/Uniswap"

## Index

### Classes

* [Uniswap](../classes/_augur_sdk_src_api_uniswap_.uniswap.md)

### Variables

* [SECONDS_FROM_NOW_DEADLINE](_augur_sdk_src_api_uniswap_.md#const-seconds_from_now_deadline)

## Variables

### `Const` SECONDS_FROM_NOW_DEADLINE

• **SECONDS_FROM_NOW_DEADLINE**: *3600* = 3600

*Defined in [packages/augur-sdk/src/api/Uniswap.ts:6](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/api/Uniswap.ts#L6)*
