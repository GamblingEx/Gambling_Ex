[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/SyncableFlexSearch"](_augur_sdk_src_state_db_syncableflexsearch_.md)

# Module: "augur-sdk/src/state/db/SyncableFlexSearch"

## Index

### Classes

* [SyncableFlexSearch](../classes/_augur_sdk_src_state_db_syncableflexsearch_.syncableflexsearch.md)

### Interfaces

* [MarketFields](../interfaces/_augur_sdk_src_state_db_syncableflexsearch_.marketfields.md)

### Variables

* [flexSearch](_augur_sdk_src_state_db_syncableflexsearch_.md#const-flexsearch)

## Variables

### `Const` flexSearch

• **flexSearch**: *any* = require('flexsearch')

*Defined in [packages/augur-sdk/src/state/db/SyncableFlexSearch.ts:4](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/db/SyncableFlexSearch.ts#L4)*
