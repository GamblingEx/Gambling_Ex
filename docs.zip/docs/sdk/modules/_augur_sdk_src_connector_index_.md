[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/connector/index"](_augur_sdk_src_connector_index_.md)

# Module: "augur-sdk/src/connector/index"

## Index

### References

* [BaseConnector](_augur_sdk_src_connector_index_.md#baseconnector)
* [DirectConnector](_augur_sdk_src_connector_index_.md#directconnector)
* [EmptyConnector](_augur_sdk_src_connector_index_.md#emptyconnector)
* [HTTPConnector](_augur_sdk_src_connector_index_.md#httpconnector)
* [SingleThreadConnector](_augur_sdk_src_connector_index_.md#singlethreadconnector)
* [WebsocketConnector](_augur_sdk_src_connector_index_.md#websocketconnector)

## References

###  BaseConnector

• **BaseConnector**:

___

###  DirectConnector

• **DirectConnector**:

___

###  EmptyConnector

• **EmptyConnector**:

___

###  HTTPConnector

• **HTTPConnector**:

___

###  SingleThreadConnector

• **SingleThreadConnector**:

___

###  WebsocketConnector

• **WebsocketConnector**:
