[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/db/ZeroXOrders.test"](_augur_sdk_src_state_db_zeroxorders_test_.md)

# Module: "augur-sdk/src/state/db/ZeroXOrders.test"


