[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/API"](_augur_sdk_src_state_getter_api_.md)

# Module: "augur-sdk/src/state/getter/API"

## Index

### Classes

* [API](../classes/_augur_sdk_src_state_getter_api_.api.md)
