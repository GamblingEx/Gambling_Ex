[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [OrderTypeHex](_augur_sdk_src_state_logs_types_.ordertypehex.md)

# Enumeration: OrderTypeHex

## Index

### Enumeration members

* [Ask](_augur_sdk_src_state_logs_types_.ordertypehex.md#ask)
* [Bid](_augur_sdk_src_state_logs_types_.ordertypehex.md#bid)

## Enumeration members

###  Ask

• **Ask**: = "0x01"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:268](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L268)*

___

###  Bid

• **Bid**: = "0x00"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:267](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L267)*
