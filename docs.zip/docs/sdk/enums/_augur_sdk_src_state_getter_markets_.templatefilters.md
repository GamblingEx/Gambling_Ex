[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Markets"](../modules/_augur_sdk_src_state_getter_markets_.md) › [TemplateFilters](_augur_sdk_src_state_getter_markets_.templatefilters.md)

# Enumeration: TemplateFilters

## Index

### Enumeration members

* [all](_augur_sdk_src_state_getter_markets_.templatefilters.md#all)
* [customOnly](_augur_sdk_src_state_getter_markets_.templatefilters.md#customonly)
* [templateOnly](_augur_sdk_src_state_getter_markets_.templatefilters.md#templateonly)

## Enumeration members

###  all

• **all**: = "all"

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:64](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L64)*

___

###  customOnly

• **customOnly**: = "customOnly"

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:66](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L66)*

___

###  templateOnly

• **templateOnly**: = "templateOnly"

*Defined in [packages/augur-sdk/src/state/getter/Markets.ts:65](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Markets.ts#L65)*
