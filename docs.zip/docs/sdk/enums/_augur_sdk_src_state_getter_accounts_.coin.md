[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/getter/Accounts"](../modules/_augur_sdk_src_state_getter_accounts_.md) › [Coin](_augur_sdk_src_state_getter_accounts_.coin.md)

# Enumeration: Coin

## Index

### Enumeration members

* [ALL](_augur_sdk_src_state_getter_accounts_.coin.md#all)
* [DAI](_augur_sdk_src_state_getter_accounts_.coin.md#dai)
* [ETH](_augur_sdk_src_state_getter_accounts_.coin.md#eth)
* [REP](_augur_sdk_src_state_getter_accounts_.coin.md#rep)

## Enumeration members

###  ALL

• **ALL**: = "ALL"

*Defined in [packages/augur-sdk/src/state/getter/Accounts.ts:54](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Accounts.ts#L54)*

___

###  DAI

• **DAI**: = "DAI"

*Defined in [packages/augur-sdk/src/state/getter/Accounts.ts:57](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Accounts.ts#L57)*

___

###  ETH

• **ETH**: = "ETH"

*Defined in [packages/augur-sdk/src/state/getter/Accounts.ts:55](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Accounts.ts#L55)*

___

###  REP

• **REP**: = "REP"

*Defined in [packages/augur-sdk/src/state/getter/Accounts.ts:56](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/getter/Accounts.ts#L56)*
