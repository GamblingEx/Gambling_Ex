[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [OrderEventAddressValue](_augur_sdk_src_state_logs_types_.ordereventaddressvalue.md)

# Enumeration: OrderEventAddressValue

## Index

### Enumeration members

* [orderCreator](_augur_sdk_src_state_logs_types_.ordereventaddressvalue.md#ordercreator)
* [orderFiller](_augur_sdk_src_state_logs_types_.ordereventaddressvalue.md#orderfiller)

## Enumeration members

###  orderCreator

• **orderCreator**: = 0

*Defined in [packages/augur-sdk/src/state/logs/types.ts:285](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L285)*

___

###  orderFiller

• **orderFiller**: = 1

*Defined in [packages/augur-sdk/src/state/logs/types.ts:286](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L286)*
