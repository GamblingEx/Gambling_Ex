[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [TokenType](_augur_sdk_src_state_logs_types_.tokentype.md)

# Enumeration: TokenType

## Index

### Enumeration members

* [DisputeCrowdsourcer](_augur_sdk_src_state_logs_types_.tokentype.md#disputecrowdsourcer)
* [ParticipationToken](_augur_sdk_src_state_logs_types_.tokentype.md#participationtoken)
* [ReputationToken](_augur_sdk_src_state_logs_types_.tokentype.md#reputationtoken)

## Enumeration members

###  DisputeCrowdsourcer

• **DisputeCrowdsourcer**:

*Defined in [packages/augur-sdk/src/state/logs/types.ts:347](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L347)*

___

###  ParticipationToken

• **ParticipationToken**:

*Defined in [packages/augur-sdk/src/state/logs/types.ts:348](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L348)*

___

###  ReputationToken

• **ReputationToken**:

*Defined in [packages/augur-sdk/src/state/logs/types.ts:346](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L346)*
