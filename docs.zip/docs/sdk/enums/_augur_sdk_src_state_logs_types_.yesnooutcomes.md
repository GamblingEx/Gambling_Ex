[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [YesNoOutcomes](_augur_sdk_src_state_logs_types_.yesnooutcomes.md)

# Enumeration: YesNoOutcomes

## Index

### Enumeration members

* [No](_augur_sdk_src_state_logs_types_.yesnooutcomes.md#no)
* [Yes](_augur_sdk_src_state_logs_types_.yesnooutcomes.md#yes)

## Enumeration members

###  No

• **No**: = "No"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:179](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L179)*

___

###  Yes

• **Yes**: = "Yes"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:180](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L180)*
