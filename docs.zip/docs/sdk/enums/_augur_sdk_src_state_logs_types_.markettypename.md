[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [MarketTypeName](_augur_sdk_src_state_logs_types_.markettypename.md)

# Enumeration: MarketTypeName

## Index

### Enumeration members

* [Categorical](_augur_sdk_src_state_logs_types_.markettypename.md#categorical)
* [Scalar](_augur_sdk_src_state_logs_types_.markettypename.md#scalar)
* [YesNo](_augur_sdk_src_state_logs_types_.markettypename.md#yesno)

## Enumeration members

###  Categorical

• **Categorical**: = "Categorical"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:169](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L169)*

___

###  Scalar

• **Scalar**: = "Scalar"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:170](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L170)*

___

###  YesNo

• **YesNo**: = "YesNo"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:168](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L168)*
