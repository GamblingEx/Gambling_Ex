[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [MarketType](_augur_sdk_src_state_logs_types_.markettype.md)

# Enumeration: MarketType

## Index

### Enumeration members

* [Categorical](_augur_sdk_src_state_logs_types_.markettype.md#categorical)
* [Scalar](_augur_sdk_src_state_logs_types_.markettype.md#scalar)
* [YesNo](_augur_sdk_src_state_logs_types_.markettype.md#yesno)

## Enumeration members

###  Categorical

• **Categorical**: = 1

*Defined in [packages/augur-sdk/src/state/logs/types.ts:163](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L163)*

___

###  Scalar

• **Scalar**: = 2

*Defined in [packages/augur-sdk/src/state/logs/types.ts:164](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L164)*

___

###  YesNo

• **YesNo**: = 0

*Defined in [packages/augur-sdk/src/state/logs/types.ts:162](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L162)*
