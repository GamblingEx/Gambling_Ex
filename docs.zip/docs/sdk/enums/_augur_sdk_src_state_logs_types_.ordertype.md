[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [OrderType](_augur_sdk_src_state_logs_types_.ordertype.md)

# Enumeration: OrderType

## Index

### Enumeration members

* [Ask](_augur_sdk_src_state_logs_types_.ordertype.md#ask)
* [Bid](_augur_sdk_src_state_logs_types_.ordertype.md#bid)

## Enumeration members

###  Ask

• **Ask**: = 1

*Defined in [packages/augur-sdk/src/state/logs/types.ts:263](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L263)*

___

###  Bid

• **Bid**: = 0

*Defined in [packages/augur-sdk/src/state/logs/types.ts:262](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L262)*
