[@augurproject/types](../README.md) › [Globals](../globals.md) › ["augur-sdk/src/state/logs/types"](../modules/_augur_sdk_src_state_logs_types_.md) › [CommonOutcomes](_augur_sdk_src_state_logs_types_.commonoutcomes.md)

# Enumeration: CommonOutcomes

## Index

### Enumeration members

* [Invalid](_augur_sdk_src_state_logs_types_.commonoutcomes.md#invalid)
* [Malformed](_augur_sdk_src_state_logs_types_.commonoutcomes.md#malformed)

## Enumeration members

###  Invalid

• **Invalid**: = "Invalid"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:175](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L175)*

___

###  Malformed

• **Malformed**: = "malformed outcome"

*Defined in [packages/augur-sdk/src/state/logs/types.ts:174](https://github.com/AugurProject/augur/blob/69c4be52bf/packages/augur-sdk/src/state/logs/types.ts#L174)*
